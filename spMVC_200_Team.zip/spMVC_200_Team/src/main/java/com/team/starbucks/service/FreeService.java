package com.team.starbucks.service;

public interface FreeService {

}
