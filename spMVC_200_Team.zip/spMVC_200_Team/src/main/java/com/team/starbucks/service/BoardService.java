package com.team.starbucks.service;

import java.util.List;

import com.team.starbucks.model.BoardDTO;

public interface BoardService {

	public List<BoardDTO> selectAll();
	
	
}
