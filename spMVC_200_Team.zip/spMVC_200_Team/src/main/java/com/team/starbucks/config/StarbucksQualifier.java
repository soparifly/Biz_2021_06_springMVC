package com.team.starbucks.config;

public class StarbucksQualifier {

	public static final String Starbucks_MAIN_SERVICE="starbucksMainServiceV1";
	public static final String Starbucks_NOTICE_SERVICE="starbucksNoticeServiceV1";
	public static final String Starbucks_EVENT_SERVICE="starbucksEventServiceV1";
	public static final String Starbucks_BOARD_SERVICE="starbucksBoardServiceV1";
	public static final String Starbucks_USER_SERVICE="starbucksUserServiceV1";
	public static final String Starbucks_CUSTOM_SERVICE="starbucksCustomServiceV1";
	
}
