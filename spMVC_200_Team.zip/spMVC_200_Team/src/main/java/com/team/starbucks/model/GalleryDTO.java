package com.team.starbucks.model;

public class GalleryDTO {

}
